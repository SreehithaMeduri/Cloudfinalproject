import os

print(os.path.join("tmp","static","UploadFiles","Households"))
os.makedirs()